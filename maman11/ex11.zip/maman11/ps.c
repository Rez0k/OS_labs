// name: Ofek Ifergan
// ID: 314820192
// Description: print processes running on the xv6 os and shows their state

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
  cps();
  exit();
}
